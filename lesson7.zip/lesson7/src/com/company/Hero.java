package com.company;

public abstract class Hero implements HavingSuperAbility {
    int health ;
    int Damage;
    String superpower;

}
