package com.company;

public class Medic extends Hero {
    @Override
    public void applySuperAbility() {
        System.out.println("Medic применил суперспособность MEDICAL HEALTH");
    }
}
